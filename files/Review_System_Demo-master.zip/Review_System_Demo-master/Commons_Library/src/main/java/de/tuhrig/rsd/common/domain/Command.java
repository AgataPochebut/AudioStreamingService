package de.tuhrig.rsd.common.domain;

public interface Command {
}

package de.tuhrig.rsd.common.domain;

public class MyEventA implements DomainEvent {
    // empty
}

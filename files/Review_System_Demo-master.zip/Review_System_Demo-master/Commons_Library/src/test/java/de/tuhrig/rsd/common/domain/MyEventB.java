package de.tuhrig.rsd.common.domain;

public class MyEventB implements DomainEvent {
    // empty
}

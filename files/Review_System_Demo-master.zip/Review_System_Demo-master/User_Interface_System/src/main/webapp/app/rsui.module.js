angular.module('rsui', [
    'ui.router'
]);
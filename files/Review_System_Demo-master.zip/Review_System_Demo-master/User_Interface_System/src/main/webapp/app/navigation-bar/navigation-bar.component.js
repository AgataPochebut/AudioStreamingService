angular.module('rsui').component('navigationBar', {
    templateUrl: 'app/navigation-bar/navigation-bar.partial.html'
});
angular.module('rsui').component('statisticsView', {
    templateUrl: 'app/statistics-view/statistics-view.partial.html',
    controller: 'StatisticsViewController'
});
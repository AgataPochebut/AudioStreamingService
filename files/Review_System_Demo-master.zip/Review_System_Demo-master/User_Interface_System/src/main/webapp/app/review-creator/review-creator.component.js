angular.module('rsui').component('reviewCreator', {
    templateUrl: 'app/review-creator/review-creator.partial.html',
    controller: 'ReviewCreatorController'
});
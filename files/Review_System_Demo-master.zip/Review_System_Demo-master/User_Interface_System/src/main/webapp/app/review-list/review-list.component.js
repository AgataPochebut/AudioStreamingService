angular.module('rsui').component('reviewList', {
    templateUrl: 'app/review-list/review-list.partial.html',
    controller: 'ReviewListController'
});
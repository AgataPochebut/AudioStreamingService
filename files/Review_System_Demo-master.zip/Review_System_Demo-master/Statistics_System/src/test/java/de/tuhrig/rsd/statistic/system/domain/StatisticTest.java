package de.tuhrig.rsd.statistic.system.domain;

public class StatisticTest {


}
exports.config = {
    framework: 'jasmine2',
    specs: ['tests/specs/*.spec.js'],
    capabilities: {
        browserName: 'chrome'
    }
};